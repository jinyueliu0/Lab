 <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
<!------ Include the above in your HEAD tag ---------->

<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">

 
 <div class="container">
    <br><br>
    <h3 style="text-align:center"> Meet our team </h3>
    <div class="row heading heading-icon">
    </div>
    <ul class="row" style="margin:20px 0">
      <li class="col-12 col-md-6 col-lg-3" style="list-style-type: none">
          <div class="cnt-block equal-hight" style="height: 600px;">
            <figure><img src="resources/anonymous.jpg"  
            height="250px" class="img-responsive" alt=""></figure>
            <h3 style="text-align:center"><a href="mailto: Liu_jinyue@gis.a-star.edu.sg">Jinyue Liu </a></h3>
            <p style="text-align:center">
            GIS Fellow | Junior Principal Investigator </p>
            <p style="text-align:center">
            Ph.D. in Neurobiology, Harvard University </p>
            <p style="text-align:center">        
            BA in Natural Sciences, University of Cambridge </p>
          </div>
      </li>
      <li class="col-12 col-md-6 col-lg-3" style="list-style-type: none">
          <div class="cnt-block equal-hight" style="height: 600px;">
            <figure><img src="resources/anonymous.jpg" height="250px" class="img-responsive" alt=""></figure>
            <h3 style="text-align:center"><a href="#">Wei-Ping Li </a></h3>
            <p style="text-align:center">Research officer</p>
          </div>
      </li>
      <li class="col-12 col-md-6 col-lg-3" style="list-style-type: none">
          <div class="cnt-block equal-hight" style="height: 600px;">
            <figure><img src="resources/anonymous.jpg" height="250px"
            class="img-responsive" alt=""></figure>
            <h3 style="text-align:center"><a href="http://www.webcoderskull.com/">Paolo Lorenzini </a></h3>
            <p style="text-align:center">Postdoctoral Fellow</p>
          </div>
       </li>
      <li class="col-12 col-md-6 col-lg-3" style="list-style-type: none">
          <div class="cnt-block equal-hight" style="height: 600px;">
            <figure><img src="resources/Guoxudong.png" height="250px" class="img-responsive" alt=""></figure>
            <h3 style="text-align:center"><a href="mailto: guoxd@gis.a-star.edu.sg">Xudong Guo </a></h3>
            <p style="text-align:center">Intern</p>
          </div>
      </li>
    </ul>
  </div>
