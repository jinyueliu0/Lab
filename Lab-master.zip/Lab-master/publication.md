<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-eOJMYsd53ii+scO/bJGFsiCZc+5NDVN2yr8+0RDqr0Ql0h+rP48ckxlpbzKgwra6" crossorigin="anonymous">

<img src="resources/Liu and Sanes 2017 with cover.png">

  * Liu J., Reggiani J.D.S., Laboulaye M.A., Pandey S., Chen B., Rubenstein J.L.R., Krishnaswamy A., Sanes J.R. Tbr1 instructs laminar patterning of retinal ganglion cell dendrites. Nature Neuroscience 2018 May; 21(5):659-670. [Image 1]
  ---
  * Liu J. and Sanes J.R. Cellular and molecular analysis of dendritic morphogenesis in a retinal cell type that senses color contrast and ventral motion. Journal of Neuroscience, 2017 Dec; 37(50) 12247-12262- Featured on journal cover and chapter cover in Principles of Neural Science, 6e edited by Eric Kandel et al.[Image 2] 
  ---
  * Duan X., Krishnaswamy A., Laboulaye M.A., Liu J., Peng Y.R., Yamagata M., Toma K. and Sanes J.R. Cadherin Combinations Recruit Dendrites of Distinct Retinal Neurons to a Shared Interneuronal Scaffold. Neuron 2018 Sept; 1145-1154.e6.
  ---
  * Agathocleous, M., Love N.K., Randlett O., Harris J.J., Liu J., Murray A.J., Harris W.A. Metabolic differentiation in the embryonic retina. Nature Cell Biology 2012 Aug; 14(8) 859-64. Featured in News and Views.
  ---

